
package pilha2;

import javax.swing.JOptionPane;

public class Exercicio2 {

    public static void main(String[] args) {
        Pilha2 pilha = new Pilha2();
        
        String dadoLaco = "S";
        String entrada = "";
        while(dadoLaco.equalsIgnoreCase("S")){
            entrada = JOptionPane.showInputDialog(
              "Insira ( ou { ou [");
                pilha.push(dadoLaco);
            dadoLaco =
            JOptionPane.showInputDialog(
            "Digite S para continuar, ou N para sair");
        }   
        
    }

    
}

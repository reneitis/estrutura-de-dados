package pilha2;

import javax.swing.JOptionPane;

public class Pilha2 {

    private int topo;
    private String vet[];
    private int n;
    
    public Pilha2(){
        topo = -1;
        n = Integer.parseInt(JOptionPane.showInputDialog("Digite o tamanho da pilha"));
        vet = new String[n];
    }
    
    
    public void push(String dado){
        if(topo == n-1){
            System.out.println("Pilha Cheia");
        }else{
                topo++;
                vet[topo] = dado;    
        }        
    }

    public String pop(){
         String dado = "";
        if(topo == -1){
            System.out.println("Pilha vazia");
        }else{
               dado = vet[topo];
            topo--;
        }
        return dado;
    }
        
     

    
    public static void main(String[] args) {
        Pilha2 pilha = new Pilha2();
        pilha.push("C");
        pilha.push("L");
        pilha.push("E");
        
        System.out.println("\n" + pilha.pop() );
    }
    
}
